"""
RULENS THOMAS 
Fonctions pour le calcul du nombre d'euler, et affichage

"""

"""
Rulens Thomas

fonction factorielles


"""
repetitae = "Valeur de E pour "
e4 = "2,7182"
e8 = "2,71828182"
e15 = "2,718281828459045"


def _facto_recur(nb):
    """Calcul de la factorielle d'un nombre avec récursivité"

    Args:
        nb ([int]): prend un nombre int en paramètre

    Returns:
        [int]: la fonction retourne la factorielle comme l'exemple suivant : 
            pour 5!
                on envoie de la fonction _facto_recur le nombre nb = 5, comme le nombre nb n'est ni égal à 0 ni égal à 1
                on return donc 5 * _facto_recur (4)
                    on rentre donc dans _facto_recur(4), comme nb = 4, il n'est ni égal à 0 ni égal à 1,
                    on return donc 4 * _facto_recur(3)
                        on rentre dans _facto_recur(3), comme nb = 3, on saute la structure conditionnelle if nb == 0 or nb == 1
                        on return donc 3 * _facto_recur(2)
                            on rentre dans _facto_recur(2), comme nb = 2, on saute la structure conditionnelle if
                            on return donc  2* _facto_recur(1)
                                on rentre dans _facto_recur(1) comme nb = 1 donc on rentre dans la structure conditionnelle, et on return 1
                                En renvoyant 1, on dépile la récurence et on retourne à l'endroit précédent, donc à récursion factorielle de 2
                            _facto_recur(2) on return 2 * 1
                            on dépile encore une fois, et on se retourne à _facto_recur(3)
                        _facto_recur(3) on return 3*2 (= 6)
                        on remonte encore une fois, et on arrive à _facto_recur(4)
                    _facto_recur(4) on return 4*6 (= 24)
                    on remonte une dernière fois, et on arrive à _facto_recur(5)
                _facto_recur(5) retourne donc finalement  5 * 24 = 120





    """
    if nb == 0 or nb == 1:
        return 1
    return nb * _facto_recur (nb-1)



def facto (nb):
    """Calcul de la factorielle d'un nombre sans récursivité

    Args:
        nb ([int]): attend un int en paramètre

    Returns:
        [int]: retourne 1 si le nombre est égal à 0 ou à 1
            et retourne le produit de la la boucle for pour le calcul de la factorielle du nombre passé en argument
    """
    if nb == 0 or nb == 1:
        return 1
    produit = 1
    for nb in range (1, nb+1): #for in range (1,nb+1) +1 parce que dans la fonction range le deuxième argument n'est pas inclusif, il faut donc lui dire d'aller à +1 pour qu'il aille au nombre voulu
        produit = produit*nb
    return produit

def euler (n):
    """Fonction qui calcule une approximation du nombre d'Euler, en fessant appel à la fonction de factorisation récurive

    Args:
        n ([int]): prend un int pour argument

    Returns:
        [float]: retourne un float
    """
    euler_nb = 0
    for i in range(n):
        euler_nb += 1/_facto_recur(i)
    return euler_nb

def affichage():
    print(f"{repetitae}2 itérations : {euler(2):1.4f} comparatif avec E à 4 décilames = {e4}")
    print(f"{repetitae}4 itérations : {euler(4):1.4f} comparatif avec E à 4 décilames = {e4}")
    print(f"{repetitae}6 itérations : {euler(6):1.4f} comparatif avec E à 4 décilames = {e4}")
    print(f"{repetitae}8 itérations : {euler(8):1.8f} comparatif avec E à 8 décilames = {e8}")
    print(f"{repetitae}10 itérations : {euler(10):1.8f} comparatif avec E à 8 décimales = {e8}")
    print(f"{repetitae}12 itérations : {euler(12)} comparatif avec E à 15 décimales = {e15}")
    print(f"{repetitae}14 itérations : {euler(14):1.15f} comparatif avec E à 15 décimales = {e15}")
    print(f"{repetitae}17 itérations : {euler(17)} comparatif avec E à 15 décimales = {e15}")


if __name__ == "__main__":
    print(_facto_recur(5))   
    
    print(facto(5))

    affichage()





