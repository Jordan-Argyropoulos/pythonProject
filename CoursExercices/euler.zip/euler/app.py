"""
Rulens Thomas Affichage du nombre D'Euler
"""
from euler import affichage


print ("""Calcul du nombre d'Euleur sur base d'itérations.
Affichage du résultat pour n = 2,4,6,8,10,12,14,17.
La valeur numérique du nombre d'Euleur tronquée à 15 déciamale est de 2,718281828459045 selon la On-Line Encyclopedia of Integer Sequences.\n
Source : https://oeis.org/A001113\n
""")

affichage()


